Action()
{

	web_add_cookie("__utmz=196215790.1620807575.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none); DOMAIN=slovardalja.net");

	web_add_cookie("__gads=ID=d7e78b5663ec665a-22237c2110c80084:T=1620807577:RT=1620807577:S=ALNI_MYl40XJo0Sm8to5FRGgPFqZoLAZhA; DOMAIN=slovardalja.net");

	web_add_cookie("__utma=196215790.1094954159.1620807575.1620807715.1620807814.3; DOMAIN=slovardalja.net");

	web_add_cookie("_ym_isad=2; DOMAIN=slovardalja.net");

	web_add_cookie("__utmb=196215790; DOMAIN=slovardalja.net");

	web_add_cookie("_ym_d=1620807578; DOMAIN=slovardalja.net");

	web_add_cookie("_ym_uid=1620807578134706808; DOMAIN=slovardalja.net");

	web_add_cookie("VID=36vaz92Fop841Wcu-N001SPm; DOMAIN=counter.yadro.ru");

	web_add_cookie("sspuid=fwAAAWCbj5iwhwAaA44/AjK49QGnd7oCL9HoAUNc9ihGIsCk; DOMAIN=ssp-rtb.sape.ru");

	web_url("slovardalja.net", 
		"URL=http://slovardalja.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://d.2ad.wtf/p.gif?ch=r&rid=aVcGY3cFUYZYJNt_dh5lDhHgrTw&if=0&qsrad=0&reg=77&id=c0005be1bf94e947bb0c5fe7d8e02f54f27a", ENDITEM, 
		"Url=http://newrrb.bid/1akds.min.js?", ENDITEM, 
		"Url=http://p.2ad.wtf/ad/base.js?id=c0005be1bf94e947bb0c5fe7d8e02f54f27a&rid=aVcGY3cFUYZYJNt_dh5lDhHgrTw&reg=77&referer=http%3A%2F%2Fslovardalja.net%2F", ENDITEM, 
		"Url=http://d.2ad.wtf/p.gif?ch=r&rid=aD7Lk-X9GslLOoasdxLZgoy5Aso&if=0&qsrad=1&reg=77&id=c0005be1bf94e947bb0c5fe7d8e02f54f27a", ENDITEM, 
		"Url=http://cdn-rtb.sape.ru/teasers/js/471/2/53471.js?", ENDITEM, 
		"Url=https://adservice.google.ru/adsid/integrator.js?domain=slovardalja.net", ENDITEM, 
		"Url=https://counter.yadro.ru/hit?t44.1;r;s1920*1080*24;uhttp%3A//slovardalja.net/;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.7028669784347324", ENDITEM, 
		"Url=https://ssp-rtb.sape.ru/data/?callback=sapeRTB_609b91c6d_61692903&srtbid=53471&scids=163225030&sx=1920&sy=962&ref=&u=http%3A%2F%2Fslovardalja.net%2F&allimps=1&fl=0&v=2&bs_625873=706,60&tz=%2B03%3A00", ENDITEM, 
		"Url=https://ssp-rtb.sape.ru/data/?callback=sapeRTB_609b91c6d_72466096&srtbid=95403&scids=93390459&sx=1920&sy=962&ref=&allimps=0&fl=0&v=2&tz=%2B03%3A00&u=http%3A%2F%2Fslovardalja.net%2F", ENDITEM, 
		"Url=https://ssp-rtb.sape.ru/data/?callback=sapeRTB_609b91c75_26406223&srtbid=53471&scids=163225030&sx=1920&sy=962&ref=&u=http%3A%2F%2Fslovardalja.net%2F&allimps=0&fl=0&v=2&deal=9&bs_625873=468,60&tz=%2B03%3A00", ENDITEM, 
		"Url=https://px2.admon.pro/pix.js?u=1600781154496&scid=&cid=53471&crid=&dl=slovardalja.net&appid=&adformat=site&traffictype=&ts=1620808134864&r=609b91c6d_83041407", ENDITEM, 
		"Url=https://px4.admon.pro/vpix.gif?callback=sapeRTB_609b91c75_26406223&srtbid=53471&scids=163225030&sx=1920&sy=962&ref=&u=1600781154496&allimps=0&fl=0&v=2&deal=9&bs_625873=468%2C60&tz=-3&vpet=&vpmrcv=0&tabts=1620808122&vpwsw=1920&vpwsh=962&vpdsw=1920&vpdsh=962&vptop=1&vpru=&pr=1000&p=Win32&tp=0&hc=0&dc=0&m=0&dw=1920&dh=1080&daw=1920&dah=1040&rs=interactive&bt=0&cn=&mt=0&rd=&hl=1&hi=0&r=0.6109155743479402&ts=1620808137428", ENDITEM, 
		"Url=https://px4.admon.pro/vpix.gif", ENDITEM, 
		LAST);

	web_add_cookie("__utma=196215790.1094954159.1620807575.1620807814.1620807814.4; DOMAIN=slovardalja.net");

	web_add_cookie("__utmc=196215790; DOMAIN=slovardalja.net");

	web_set_sockets_option("SSL_VERSION", "2&3");

	/* ����� ����� */

	web_link("�", 
		"Text=�", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://slovardalja.net");

	web_url("1akds.json", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22start%22%2C%22ts%22%3A386%7D%5D&url=&v=2.2.3-a5b3115&r=4xs3yet7cs&referrer=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://counter.yadro.ru/hit?t44.1;rhttp%3A//slovardalja.net/;s1920*1080*24;uhttp%3A//slovardalja.net/letter.php%3Fcharkod%3D192;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.49637103121666387", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		LAST);

	web_custom_request("1akds.json_2", 
		"URL=http://newrrb.bid/1akds.json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"blocksId\":[\"9050\",\"148752\",\"149099\"],\"isAdBlock\":false,\"url\":\"http://slovardalja.net/letter.php?charkod=192\",\"v\":\"2.2.3-~~SHA~VERSION~STRING~~\",\"r\":\"4xs3yet7cs\",\"city\":null,\"region\":null,\"countryCode\":null,\"width\":1920,\"skip\":[],\"referrer\":\"http://slovardalja.net/\",\"sessionReferrer\":\"http://no.domain/\"}", 
		EXTRARES, 
		"Url=https://px2.admon.pro/pix.js?u=1600781154496&scid=&cid=53471&crid=&dl=slovardalja.net&appid=&adformat=site&traffictype=&ts=1620808138250&r=609b91ca4_60580998", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		"Url=https://adservice.google.ru/adsid/integrator.js?domain=slovardalja.net", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		"Url=https://ssp-rtb.sape.ru/data/?callback=sapeRTB_609b91ca4_88893181&srtbid=95403&scids=93390459&sx=1920&sy=962&ref=http%3A%2F%2Fslovardalja.net%2F&allimps=0&fl=0&v=2&tz=%2B03%3A00&u=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		"Url=https://ssp-rtb.sape.ru/data/?callback=sapeRTB_609b91ca4_88893181&srtbid=95403&scids=93390459&sx=1920&sy=962&ref=http%3A%2F%2Fslovardalja.net%2F&allimps=0&fl=0&v=2&tz=%2B03%3A00", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		"Url=https://px2.admon.pro/vpix.gif", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		LAST);

	web_url("1akds.json_3", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22loaded%22%2C%22ts%22%3A402%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A9050%2C%22ts%22%3A447%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A148752%2C%22ts%22%3A447%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A149099%2C%22ts%22%3A447%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&v=2.2.3-a5b3115&r=4xs3yet7cs&referrer=http%3A%2F%2Fslovardalja.net%2F", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1akds.json_4", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22injected%22%2C%22bId%22%3A9050%2C%22aId%22%3A30300%2C%22ts%22%3A955%7D%2C%7B%22t%22%3A%22injected%22%2C%22bId%22%3A148752%2C%22aId%22%3A467569%2C%22ts%22%3A961%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&v=2.2.3-a5b3115&r=4xs3yet7cs&referrer=http%3A%2F%2Fslovardalja.net%2F", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://px2.admon.pro/vpix.gif?callback=sapeRTB_609b91ca4_88893181&srtbid=95403&scids=93390459&sx=1920&sy=962&ref=http%3A%2F%2Fslovardalja.net%2F&allimps=0&fl=0&v=2&tz=-3&u=1600781154496&vpet=&vpmrcv=0&tabts=1620808137&vpwsw=1920&vpwsh=962&vpdsw=1903&vpdsh=3769&vptop=1&vpru=http%253A%252F%252Fslovardalja.net%252F&pr=1000&p=Win32&tp=0&hc=0&dc=0&m=0&dw=1920&dh=1080&daw=1920&dah=1040&rs=interactive&bt=0&cn=&mt=0&rd=&hl=2&hi=0&r=0.8004452715131485&ts=1620808138520", "Referer=http://slovardalja.net"
		"/letter.php?charkod=192", ENDITEM, 
		LAST);

	web_url("1akds.json_5", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22injected%22%2C%22bId%22%3A149099%2C%22aId%22%3A466414%2C%22ts%22%3A1090%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&v=2.2.3-a5b3115&r=4xs3yet7cs&referrer=http%3A%2F%2Fslovardalja.net%2F", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("yabs-vdrf=A0; DOMAIN=an.yandex.ru");

	web_add_cookie("ymex=1936167586.yrts.1620807586#1936167586.yrtsi.1620807586; DOMAIN=an.yandex.ru");

	web_add_cookie("yandexuid=7100717061620807586; DOMAIN=an.yandex.ru");

	web_add_cookie("i=+zqq2WEDMgDHrwlpZQlesrl3QXYTkfyzv4QNb16JVxee+l6TCXGqOUQWj4X3eVDH/3IyPxtte+dMkVfJ+PIQo9olkUg=; DOMAIN=an.yandex.ru");

	web_url("1akds.json_6", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22thick%22%2C%22bId%22%3A149099%2C%22aId%22%3A466414%2C%22ts%22%3A1180%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&v=2.2.3-a5b3115&r=4xs3yet7cs&referrer=http%3A%2F%2Fslovardalja.net%2F", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://an.yandex.ru/system/context.js", "Referer=http://slovardalja.net/letter.php?charkod=192", ENDITEM, 
		LAST);

	web_custom_request("224874", 
		"URL=https://an.yandex.ru/meta/224874?grab=dNCi0L7Qu9C60L7QstGL0Lkg0YHQu9C-0LLQsNGA0Ywg0JTQsNC70Y8g0L7QvdC70LDQudC9CjHQotC-0LvQutC-0LLRi9C5INGB0LvQvtCy0LDRgNGMINCU0LDQu9GPINC-0L3Qu9Cw0LnQvSAK&target-ref=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&page-ref=http%3A%2F%2Fslovardalja.net%2F&charset=utf-8&pcode-test-ids=360906%2C0%2C17%3B360200%2C0%2C25%3B356981%2C0%2C7%3B330366%2C0%2C41%3B351578%2C0%2C85%3B359828%2C0%2C24&pcode-flags="
		"%7B%22COMBO_HEADER%22%3A%22withoutHeader%22%2C%22USE_SUPERBUNDLE%22%3Atrue%2C%22USE_SMART_SSR%22%3A%221%22%2C%22DEFAULT_SSR_FORMATS%22%3A%5B%22zen%22%2C%22zen2%22%2C%22zen2-gallery%22%2C%22billboard%22%2C%22horizontal%22%2C%22horizontal0318%22%2C%22constructor%22%2C%22modernAdaptive%22%5D%2C%22SSR_PERCENT_LOGGING%22%3A0.01%2C%22ADAPTIVE_TOWER_VIDEO%22%3A%22exp%22%2C%22DEFAULT_BLACKLIST_PAGES%22%3A%5B%22419507%22%2C%22419506%22%2C%22106253%22%2C%22188382%22%2C%22189903%22%5D%2C%22COMBO_PACKSHOT_EXP"
		"%22%3A%22exp%22%2C%22LEADERBOARD_VIDEO%22%3A%22ctl%22%2C%22VIDEO_EARS_FLAGS%22%3A%22ctl%22%2C%22PCODEVER%22%3A%2214603%22%7D&server-side-rendering-enabled-formats=zen%0Azen2%0Azen2-gallery%0Abillboard%0Ahorizontal%0Ahorizontal0318%0Aconstructor%0AmodernAdaptive&raw-smart-content=1&smart-format-names=smart-banner-adaptive_v1%0Asmart-banner-mosaic_v1&pcode-icookie=7100717061620807586&duid=MTYyMDgwNzU3ODEzNDcwNjgwOA%3D%3D&imp-id=4&enable-flat-highlight=1&test-tag=146784802308098&ad-session-id="
		"9872451620808139242&target-id=50599649&tga-with-creatives=1&pcode-version=14603&pcodever=14603&flash-ver=0&available-width=706&layout-config=%7B%22win_width%22%3A1920%2C%22win_height%22%3A962%2C%22pixel_ratio%22%3A1%2C%22bandwidth%22%3A-1%2C%22w%22%3A706%2C%22h%22%3A0%2C%22width%22%3A706%2C%22height%22%3A0%2C%22visible%22%3A1%2C%22left%22%3A617%2C%22top%22%3A293%2C%22ad_no%22%3A0%2C%22req_no%22%3A0%7D&callback=Ya%5B3401510228592%5D", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded", 
		LAST);

	/* ����� ����� */

	web_revert_auto_header("Origin");

	lr_think_time(5);

	web_url("word.php", 
		"URL=http://slovardalja.net/word.php?wordid=10", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://slovardalja.net/letter.php?charkod=192", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://slovardalja.net");

	web_url("1akds.json_7", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22start%22%2C%22ts%22%3A641%7D%5D&url=&v=2.2.3-a5b3115&r=in51uhpkq7&referrer=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://counter.yadro.ru/hit?t44.1;rhttp%3A//slovardalja.net/letter.php%3Fcharkod%3D192;s1920*1080*24;uhttp%3A//slovardalja.net/word.php%3Fwordid%3D10;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.37119515121694", "Referer=http://slovardalja.net/word.php?wordid=10", ENDITEM, 
		LAST);

	web_custom_request("1akds.json_8", 
		"URL=http://newrrb.bid/1akds.json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"blocksId\":[\"9050\",\"148752\",\"149099\"],\"isAdBlock\":false,\"url\":\"http://slovardalja.net/word.php?wordid=10\",\"v\":\"2.2.3-~~SHA~VERSION~STRING~~\",\"r\":\"in51uhpkq7\",\"city\":null,\"region\":null,\"countryCode\":null,\"width\":1920,\"skip\":[],\"referrer\":\"http://slovardalja.net/letter.php?charkod=192\",\"sessionReferrer\":\"http://no.domain/\"}", 
		EXTRARES, 
		"Url=https://adservice.google.ru/adsid/integrator.js?domain=slovardalja.net", "Referer=http://slovardalja.net/word.php?wordid=10", ENDITEM, 
		LAST);

	web_url("1akds.json_9", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22loaded%22%2C%22ts%22%3A649%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A9050%2C%22ts%22%3A664%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A148752%2C%22ts%22%3A664%7D%2C%7B%22t%22%3A%22fetch%22%2C%22bId%22%3A149099%2C%22ts%22%3A665%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fword.php%3Fwordid%3D10&v=2.2.3-a5b3115&r=in51uhpkq7&referrer=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("1akds.json_10", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22injected%22%2C%22bId%22%3A9050%2C%22aId%22%3A30300%2C%22ts%22%3A1011%7D%2C%7B%22t%22%3A%22injected%22%2C%22bId%22%3A148752%2C%22aId%22%3A467569%2C%22ts%22%3A1018%7D%2C%7B%22t%22%3A%22injected%22%2C%22bId%22%3A149099%2C%22aId%22%3A466414%2C%22ts%22%3A1066%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fword.php%3Fwordid%3D10&v=2.2.3-a5b3115&r=in51uhpkq7&referrer=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://adservice.google.ru/adsid/integrator.js?domain=slovardalja.net", "Referer=http://slovardalja.net/word.php?wordid=10", ENDITEM, 
		LAST);

	web_url("1akds.json_11", 
		"URL=http://newrrb.bid/1akds.json?stat=%5B%7B%22t%22%3A%22thick%22%2C%22bId%22%3A149099%2C%22aId%22%3A466414%2C%22ts%22%3A1075%7D%5D&url=http%3A%2F%2Fslovardalja.net%2Fword.php%3Fwordid%3D10&v=2.2.3-a5b3115&r=in51uhpkq7&referrer=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("224874_2", 
		"URL=https://an.yandex.ru/meta/224874?grab=dNCi0L7Qu9C60L7QstGL0Lkg0YHQu9C-0LLQsNGA0Ywg0JTQsNC70Y8g0L7QvdC70LDQudC9CjHQotC-0LvQutC-0LLRi9C5INGB0LvQvtCy0LDRgNGMINCU0LDQu9GPINC-0L3Qu9Cw0LnQvSAK&target-ref=http%3A%2F%2Fslovardalja.net%2Fword.php%3Fwordid%3D10&page-ref=http%3A%2F%2Fslovardalja.net%2Fletter.php%3Fcharkod%3D192&charset=utf-8&pcode-test-ids=360906%2C0%2C17%3B360200%2C0%2C25%3B356981%2C0%2C7%3B330366%2C0%2C41%3B351578%2C0%2C85%3B359828%2C0%2C24&pcode-flags="
		"%7B%22COMBO_HEADER%22%3A%22withoutHeader%22%2C%22USE_SUPERBUNDLE%22%3Atrue%2C%22USE_SMART_SSR%22%3A%221%22%2C%22DEFAULT_SSR_FORMATS%22%3A%5B%22zen%22%2C%22zen2%22%2C%22zen2-gallery%22%2C%22billboard%22%2C%22horizontal%22%2C%22horizontal0318%22%2C%22constructor%22%2C%22modernAdaptive%22%5D%2C%22SSR_PERCENT_LOGGING%22%3A0.01%2C%22ADAPTIVE_TOWER_VIDEO%22%3A%22exp%22%2C%22DEFAULT_BLACKLIST_PAGES%22%3A%5B%22419507%22%2C%22419506%22%2C%22106253%22%2C%22188382%22%2C%22189903%22%5D%2C%22COMBO_PACKSHOT_EXP"
		"%22%3A%22exp%22%2C%22LEADERBOARD_VIDEO%22%3A%22ctl%22%2C%22VIDEO_EARS_FLAGS%22%3A%22ctl%22%2C%22PCODEVER%22%3A%2214603%22%7D&server-side-rendering-enabled-formats=zen%0Azen2%0Azen2-gallery%0Abillboard%0Ahorizontal%0Ahorizontal0318%0Aconstructor%0AmodernAdaptive&raw-smart-content=1&smart-format-names=smart-banner-adaptive_v1%0Asmart-banner-mosaic_v1&pcode-icookie=7100717061620807586&duid=MTYyMDgwNzU3ODEzNDcwNjgwOA%3D%3D&imp-id=4&enable-flat-highlight=1&test-tag=146784802308098&ad-session-id="
		"5870681620808148623&target-id=92939400&tga-with-creatives=1&pcode-version=14603&pcodever=14603&flash-ver=0&available-width=700&layout-config=%7B%22win_width%22%3A1920%2C%22win_height%22%3A962%2C%22pixel_ratio%22%3A1%2C%22bandwidth%22%3A-1%2C%22w%22%3A700%2C%22h%22%3A0%2C%22width%22%3A700%2C%22height%22%3A0%2C%22visible%22%3A1%2C%22left%22%3A628%2C%22top%22%3A292%2C%22ad_no%22%3A0%2C%22req_no%22%3A0%7D&callback=Ya%5B4681660903295%5D", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://slovardalja.net/word.php?wordid=10", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded", 
		LAST);

	return 0;
}